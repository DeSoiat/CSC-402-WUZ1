# Assets Licenses
## [Pexels](https://www.pexels.com/license/)

### Michelangelo Buonarroti
- https://www.pexels.com/video/couple-doing-step-aerobics-using-chairs-4259066/
- https://www.pexels.com/video/a-couple-squat-exercising-at-home-4258996/
- https://www.pexels.com/video/a-bearded-man-exercising-at-home-4260553/

### Olia Danilevich
- https://www.pexels.com/video/a-woman-exercising-at-home-4352387/

### Bruno Nascimento
- https://unsplash.com/photos/PHIgYUGQPvU

### Annie Spratt
- https://www.peopleperhour.com/blog/wp-content/uploads/2019/05/annie-spratt-0OzIvSj7klM-unsplash.jpg

### Logan Weaver
- https://unsplash.com/photos/u76Gd0hP5w4

### Bruce Mars
- https://unsplash.com/photos/gJtDg6WfMlQ

### Free To Use Sounds
- https://unsplash.com/photos/YyqOW5ovgjA
