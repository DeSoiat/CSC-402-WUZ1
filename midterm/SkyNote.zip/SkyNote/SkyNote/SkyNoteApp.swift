//
//  SkyNoteApp.swift
//  SkyNote
//
//  Created by desoiat on 3/16/22.
//

import SwiftUI

@main
struct SkyNoteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
