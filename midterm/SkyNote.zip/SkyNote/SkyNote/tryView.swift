//
//  tryView.swift
//  SkyNote
//
//  Created by desoiat on 3/20/22.
//

import SwiftUI

struct Items: Identifiable {
  let id = UUID()
  var name: String
  var isChecked: Bool = false
}


struct tryView: View {
    

    @State private var items = [
        Items(name: "1", isChecked: false),
        Items(name: "2", isChecked: false),
        Items(name: "3", isChecked: false)
  ]
    
    var body: some View {
        NavigationView {
            List {
                
                ForEach(items) { items in
                    HStack {
                      Text(items.name)
                      Spacer()
                      Text(items.isChecked ? "√" : "☐")
                    }
                    .onTapGesture {
                      if let matchingIndex =
                        self.items.firstIndex(where: { $0.id == items.id }) {
                        self.items[matchingIndex].isChecked.toggle()
                      }
                    }
                    
                    
                }
            }
            .navigationBarTitle(Text("SkyNote"))
            .navigationBarItems(trailing: Button(action: {
                self.addRow()
            }) {
                Image(systemName: "plus")
            })
        }
        
        .navigationBarTitle("SkyNote")
        
        
    }
        

    private func addRow() {
        let newItem = Items(name: "new Items")
        self.items.append(newItem)
    }
}

struct tryView_Previews: PreviewProvider {
    static var previews: some View {
        tryView()
    }
}
