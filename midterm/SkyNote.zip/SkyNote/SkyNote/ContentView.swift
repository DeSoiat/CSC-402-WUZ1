//
//  tryView.swift
//  SkyNote
//
//  Created by desoiat on 3/20/22.
//

import SwiftUI

struct Items: Identifiable {
  let id = UUID()
  var name: String
  var isChecked: Bool = false
}


struct ContentView: View {
    

    @State private var items = [
        Items(name: "Click + to add new items", isChecked: false),
        Items(name: "Click ☐ to change it to √", isChecked: false),
   
  ]
    
    var body: some View {
        NavigationView {
            List {
                
                ForEach(items) { items in
                    HStack {
                      Text(items.name)
                      Spacer()
                      Text(items.isChecked ? "√" : "☐")
                    }
                    .onTapGesture {
                      if let matchingIndex =
                        self.items.firstIndex(where: { $0.id == items.id }) {
                        self.items[matchingIndex].isChecked.toggle()
                      }
                    }
                    
                    
                }
            }
            .navigationBarTitle(Text("SkyNote"))
            
            .navigationBarItems(trailing: Button(action: {
                self.addRow()
            }) {
                Image(systemName: "plus")
            })
        }
        
        .navigationBarTitle("SkyNote")
        
        
    }
        

    private func addRow() {
        let newItem = Items(name: "new items")
        self.items.append(newItem)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

